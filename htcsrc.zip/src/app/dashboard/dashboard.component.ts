import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EmployeeregisterComponent } from '../employeeregister/employeeregister.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  employeeData=[{username:'Venkatesh',salary:23356766,address:'Salem'}]
  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }
  openEmployeeForm(){
    this.modalService.open(EmployeeregisterComponent).result.then((result) => {
      if(result){
        this.employeeData.push(result)
      }
    }, (reason) => {
      
    });


  }
}
