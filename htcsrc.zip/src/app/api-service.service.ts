import { Injectable } from '@angular/core';
import { element } from 'protractor';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {
userLogin=[{name:'Venky',password:'163@Chu'},{name:'Venky2',password:'163@Chuchu'},{name:'Venky3',password:'123@Chuchu'}]
session=new Subject();
  constructor() {

   }

   checklogin(data){
     return new Promise((resolve)=>{
      let result=false;
      this.userLogin.forEach(element => {
        if(data.username==element.name&&data.password==element.password){
          result=true;
        }       
       });
       resolve(result);
  
     })
     
   }

}
