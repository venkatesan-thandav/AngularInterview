// import { Component, ElementRef, ViewChild } from '@angular/core';
import { Component } from "@angular/core";
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiServiceService } from "./api-service.service";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})
export class AppComponent {

  loginForm: FormGroup;
  alertMsg: any;
  sessionValue:any=false;
  constructor(public service: ApiServiceService, public route: Router) {
  }
  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    })
    this.service.session.subscribe((data:any)=>{
this.sessionValue=data;
    })
  }
  onSubmit() {
    console.log(this.loginForm)
    this.service.checklogin(this.loginForm.value).then((result: any) => {
      console.log(result)
      if (result) {
        
        
this.route.navigate(['dashboard'])
      } else {
        this.alertMsg = "Login Failure"
      }
      this.service.session.next(result)
    })
  }
}


