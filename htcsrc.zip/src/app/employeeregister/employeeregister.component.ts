import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-employeeregister',
  templateUrl: './employeeregister.component.html',
  styleUrls: ['./employeeregister.component.css']
})
export class EmployeeregisterComponent implements OnInit {
  RegisterForm: FormGroup;
  alertMsg:any
  options = [
    {
        id: "Yes",
        value: 'Yes'
    },
    {
        id: "No",
        value: 'No'
    }];
  constructor(public modal: NgbActiveModal) { }

  ngOnInit() {
    this.RegisterForm = new FormGroup({
      username: new FormControl('Enter the Name', Validators.required),
      salary: new FormControl('Salary', Validators.required),
      address: new FormControl('Enter the Address', Validators.required),
      paddress:new FormControl('Enter the PermanentAddress', Validators.required),
      yorN:new FormControl('', Validators.required),
    })
  }
  onSubmit(){
console.log(this.RegisterForm);
this.modal.close(this.RegisterForm.value)
  }
  changeStatus(){
    console.log(this.RegisterForm.value['yorN'])
    this.RegisterForm.value['paddress']="Test"
 
  }
}
