import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiServiceService } from '../api-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  alertMsg: any;
  sessionValue:any=false;
  constructor(public service: ApiServiceService, public route: Router) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    })
    this.service.session.subscribe((data:any)=>{
this.sessionValue=data;
  })
}

  onSubmit() {
    console.log(this.loginForm)
    this.service.checklogin(this.loginForm.value).then((result: any) => {
      console.log(result)
      if (result) {
        
        
this.route.navigate(['dashboard'])
      } else {
        this.alertMsg = "Login Failure"
      }
      this.service.session.next(result)
    })
  }
}
